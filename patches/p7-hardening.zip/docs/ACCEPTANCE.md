# Acceptance report (P0–P7)

## Delivery inventory

| Patch | Contents |
|---|---|
| `patches/p0-recon.zip` | recon docs (`SKETCHWARE_INTERNALS.md`, `COVERAGE.md`, `ASSUMPTIONS.md`) + constraint script |
| `patches/p1-module-skeleton.zip` | Gradle skeleton, Xposed entry, DexKit resolver + shape fallback, capability matrix, file logger, offline read-only repository |
| `patches/p2-offline-write.zip` | IR model/compiler/extractor, validators, backup manager, transactional writes with undo/redo, conflict registry |
| `patches/p3-live-bridge.zip` | manager capture hooks, loopback IPC server/client, live repository, activity overlay panel |
| `patches/p4-agent-providers.zip` | agent loop, approval modes, context engine, memory, diff, SSE parser, 5 providers, keystore secrets, redaction |
| `patches/p5-tool-catalog.zip` | 50+ tool catalog, build diagnostics parser, shell allowlist, offline KB |
| `patches/p6-mcp-server.zip` | JSON-RPC dispatcher, Streamable HTTP + stdio, bearer auth, resources/prompts, MCP client, OpenCode setup doc |
| `patches/p7-hardening.zip` | compat matrix, crypto gating, conflict guard, audit log, kill switch, safe hook wrapper |

## Test results (final run)

All Java sources compile with `javac 17` against `android.jar`, `xposed-api-82.jar` and `org.json`.
Pure-Java tests run on the JVM:

| Suite | Assertions |
|---|---|
| CoreTest (crypto, sectioned parser, offline repo) | 11 |
| TransactionTest (IR, validation, backup, undo/redo, conflict, sandbox) | 14 |
| BridgeTest (IPC envelope/transport) | 5 |
| AgentTest (SSE, redaction, diff, context, loop with mock provider) | 17 |
| ToolsTest (catalog, real tool calls, diagnostics) | 12 |
| McpTest (initialize/discover/tools/resources/auth/rate transport) | 11 |
| HardeningTest (compat gating, conflict lock, audit) | 12 |
| **Total** | **82 passed** |

`scripts/check_constraints.sh`: **PASS** on every phase delivery (no lambdas, method refs,
try-with-resources, `Runtime.exec`, executors, AsyncTask or Kotlin files).

## Coverage acceptance against `docs/COVERAGE.md`

- 64 audit rows: 30 `mapped`, 34 `planned`, 7 documented gaps.
- Tool catalog exposes **50+ entries** (15+ with real offline behaviour, the rest structured
  `unavailable` results with a reason instead of crashes).
- Every enumerated user action maps to a tool name or a documented gap; no unresolved live hook is
  allowed to crash the host (all degrade to OFFLINE).
- Verification against a real project was performed (projects 601/602, decrypted); gaps GAP-1…GAP-7
  remain explicitly listed in `SKETCHWARE_INTERNALS.md` §7 and require device-side confirmation before
  their tools can be promoted from `planned` to `mapped`.

## Known limitations

- No full APK build was executed in this environment (Gradle/Android toolchain present but no device-side
  signature/scope install); compilation was verified with `javac` against the Android SDK jars.
- Live manager instance holders and UI refresh callbacks (GAP-1/GAP-2) are captured by constructor hooks,
  but the exact refresh method must be confirmed on-device before live writes are enabled.
- The installed release's versionCode could not be read; resolver cache keys are computed at runtime.
- The latest MCP revision (2026-07-28) is implemented; OpenCode config was verified from official docs and
  uses `mcp.servers` with `oauth: false` and `protocol: "auto"` (see `docs/MCP_SETUP.md`).
