package snd.sketchpilot.core.hook;

import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import snd.sketchpilot.util.Logger;

/** Xposed implementation of HookBridge. Every callback is wrapped in try/catch(Throwable). */
public final class XposedHookBridge implements HookBridge {

    private boolean enabled = true;
    private final CapabilityMatrix matrix = new CapabilityMatrix();

    public String getName() {
        return "xposed";
    }

    public List<Capability> getCapabilities() {
        return matrix.getCapabilities();
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void activate(HookContext context) throws Throwable {
        if (!enabled) {
            Logger.d("Hook", "global kill switch active; not registering hooks");
            return;
        }
        try {
            matrix.evaluate(context.getResolver());
            matrix.saveSnapshot(snapshotFile());

            // P1: a single safe diagnostic hook proves the wrapper works. Real
            // feature hooks are added in P3 by the live bridge.
            XposedHelpers.findAndHookMethod(
                    "android.app.Application",
                    context.getClassLoader(),
                    "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            try {
                                Logger.d("Hook", "host application started: " + context.getPackageName()
                                        + " versionKey=" + context.getVersionKey());
                            } catch (Throwable t) {
                                Logger.hookFailure("Application.onCreate", t);
                            }
                        }
                    });
            Logger.d("Hook", "Xposed hooks registered; live capabilities="
                    + countLive() + "/" + matrix.getCapabilities().size());
        } catch (Throwable t) {
            Logger.hookFailure("XposedHookBridge.activate", t);
        }
    }

    private int countLive() {
        int count = 0;
        List<Capability> list = matrix.getCapabilities();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).isLive()) {
                count++;
            }
        }
        return count;
    }

    private static java.io.File snapshotFile() {
        return new java.io.File("/storage/emulated/0/.sketchware/sketchpilot/capabilities.json");
    }
}
