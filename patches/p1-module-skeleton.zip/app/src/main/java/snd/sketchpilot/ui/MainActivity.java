package snd.sketchpilot.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.List;

import snd.sketchpilot.project.OfflineRepository;
import snd.sketchpilot.project.SketchwarePaths;
import snd.sketchpilot.project.crypto.SketchwareCrypto;
import snd.sketchpilot.project.model.ProjectInfo;

/** Companion app entry point (P1 shell; provider/MCP screens arrive in P4/P6). */
public final class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = 24;
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("SketchPilot — Phase 1");
        title.setTextSize(20f);
        root.addView(title);

        TextView summary = new TextView(this);
        summary.setText("Offline projects discovered: " + countProjects());
        root.addView(summary);

        Button capabilities = new Button(this);
        capabilities.setText("Capability Matrix");
        capabilities.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CapabilityActivity.class));
            }
        });
        root.addView(capabilities);

        setContentView(root);
    }

    private static int countProjects() {
        try {
            OfflineRepository repo = new OfflineRepository(new SketchwarePaths(new File("/storage/emulated/0")),
                    new SketchwareCrypto());
            List<ProjectInfo> projects = repo.listProjects();
            return projects.size();
        } catch (Throwable t) {
            return 0;
        }
    }
}
